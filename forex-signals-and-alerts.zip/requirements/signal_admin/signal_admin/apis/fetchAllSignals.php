<?php
$connect = mysqli_connect("localhost", "root", "", "signals");
$query = "SELECT * FROM allsignals ORDER BY lastUpdate DESC LIMIT 700";
$result = mysqli_query($connect, $query);
$rows = array();
while ($row = mysqli_fetch_array($result)) {
    $rows[] = $row;
}

print json_encode($rows);