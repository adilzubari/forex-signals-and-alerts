<?php
$connect = mysqli_connect("localhost", "root", "", "signals");
$query = "SELECT * FROM results where signal_id=".$_GET['id']." ORDER BY id ";
$result = mysqli_query($connect, $query);
$rows = array();
while ($row = mysqli_fetch_array($result)) {
    $rows[] = $row;
}

print json_encode($rows);