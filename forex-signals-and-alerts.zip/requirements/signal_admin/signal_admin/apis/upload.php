<?php
  $db = mysqli_connect("localhost", "root", "", "signals");
if ($db->connect_error) {
    die("Connection failed: " . $db->connect_error);
}
$statusMsg = '';

// File upload path
$targetDir = "../uploads/";
$fileName = basename($_POST['id']."-".$_FILES["file"]["name"]);
$targetFilePath = $targetDir . $fileName;
$fileType = pathinfo($targetFilePath,PATHINFO_EXTENSION);

if(!empty($_FILES["file"]["name"])){
    // Allow certain file formats
    $allowTypes = array('jpg','png','jpeg','gif','pdf');
    if(in_array($fileType, $allowTypes)){
        // Upload file to server
        if(move_uploaded_file($_FILES["file"]["tmp_name"], $targetFilePath)){
            // Insert image file name into database
            $insert = $db->query("INSERT into results (url, signal_id) VALUES ('".$fileName."', '".$_POST['id']."')");
            if($insert){
                $statusMsg = "The file ".$fileName. " has been uploaded successfully.";
                 header("Location: ../dashboard.php");
                 die();
            }else{
                $statusMsg = "File upload failed, please try again.";

            }
        }else{
            $statusMsg = "Sorry, there was an error uploading your file.";

        }
    }else{
        $statusMsg = 'Sorry, only JPG, JPEG, PNG, GIF, & PDF files are allowed to upload.';
    }
}else{
    $statusMsg = 'Please select a file to upload.';
}

// Display status message
echo $statusMsg;
?>