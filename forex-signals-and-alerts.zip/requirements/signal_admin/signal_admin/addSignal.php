<?php
ob_start();
session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <?php include("head.html") ?>
</head>
<body class="hold-transition sidebar-mini layout-fixed">
<div class="wrapper">

  <!-- Preloader -->
  <div class="preloader flex-column justify-content-center align-items-center">
    <img class="animation__shake" src="dist/img/AdminLTELogo.png" alt="AdminLTELogo" height="60" width="60">
  </div>

   <?php include("header.php")?>
   <?php include("sidebar.php")?>

<?php

        if($_SESSION['status']=="logged_in"){

            // Enabling error reporting
            error_reporting(-1);
            ini_set('display_errors', 'On');

            require_once __DIR__ . '/firebase.php';
            require_once __DIR__ . '/push.php';

            $firebase = new Firebase();
            $push = new Push();

            $title = isset($_GET['title']) ? $_GET['title'] : '';
            if(isset($_GET['title'])) {
                $action = isset($_GET['action']) ? $_GET['action'] : '';
                $status = isset($_GET['status']) ? $_GET['status'] : '';
                $openPrice = isset($_GET['openPrice']) ? $_GET['openPrice'] : '';
                $push_type = isset($_GET['push_type']) ? $_GET['push_type'] : '';
                $openingTime = date("Y-m-d H:i:s");
                $lastUpdate = $openingTime;
                $comment = isset($_GET['comment']) ? $_GET['comment'] : '';
                $takeProfit1 = isset($_GET['takeProfit1']) ? $_GET['takeProfit1'] : '';
                $takeProfit2 = isset($_GET['takeProfit2']) ? $_GET['takeProfit2'] : '';
                $takeProfit3 = isset($_GET['takeProfit3']) ? $_GET['takeProfit3'] : '';
                $type = isset($_GET['type']) ? $_GET['type'] : '';
                $stopLoss = isset($_GET['stopLoss']) ? $_GET['stopLoss'] : '';
                $profitLoss = isset($_GET['profitLoss']) ? $_GET['profitLoss'] : '';

                $conn = mysqli_connect("localhost", "root", "", "signals");
                if ($conn->connect_error) {
                    die("Connection failed: " . $conn->connect_error);
                }

                $sql = "INSERT INTO `allsignals`(`title`, `openPrice`, `action`, `status`, `takeProfit1`,
                         `takeProfit2`, `takeProfit3`, `stopLoss`, `profitLoss`, `comments`,`type`)
                          VALUES ('" . $title . "','" . $openPrice . "','" . $action . "','" . $status . "',
                                  '" . $takeProfit1 . "','" . $takeProfit2 . "','" . $takeProfit3 . "','" . $stopLoss . "','" . $profitLoss . "','" . $comment . "','" . $type . "')";

                if ($conn->query($sql) === TRUE) {
                    echo "New record created successfully";
                } else {
                    echo "Error: " . $sql . "<br>" . $conn->error;
                }

                $push->setTitle($title);
                $push->setAction($action);
                $push->setOpenPrice($openPrice);
                $push->setStatus($status);

                $json = '';
                $response = '';

                if ($push_type == 'topic') {
                    $json = $push->getPush();
                    $response = $firebase->sendToTopic('global', $json);
                } else if ($push_type == 'individual') {
                    $json = $push->getPush();
                    //$regId = isset($_GET['regId']) ? $_GET['regId'] : '';
                    $regId = "PUT YOUR DEVICE ID HERE";
                    $response = $firebase->send($regId, $json);
                }

                header("Location: dashboard.php");
                die();
            }}
            ?>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <div class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1 class="m-0">Dashboard</h1>
          </div><!-- /.col -->
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="#">Home</a></li>
              <li class="breadcrumb-item active">Dashboard v1</li>
            </ol>
          </div><!-- /.col -->
        </div><!-- /.row -->
      </div><!-- /.container-fluid -->
    </div>
    <!-- /.content-header -->

    <!-- Main content -->
    <section class="content">
      <div class="container-fluid">
        <!-- Small boxes (Stat box) -->
        <div class="row">
        <div class="col-md-9 card card-primary">
          <div class="card-header">
            <h3 class="card-title">Update Signal</h3>
          </div>
          <!-- /.card-header -->
          <!-- form start -->

          <form method="get">
            <div class="card-body">
              <div class="form-group">
                 <label for="exampleInputEmail1">Title</label>
                 <input type="text" id="title" class="form-control" name="title" class="pure-input-1-2" placeholder="Enter title" required>
              </div>
              <div class="form-group">
                 <label for="exampleInputEmail1">Open Price</label>
                 <input type="text" id="openPrice" class="form-control" name="openPrice" class="pure-input-1-2" placeholder="Enter Open Price" required>
              </div>
              <div class="form-group">
                 <label for="exampleInputEmail1">Take Profit 1</label>
                 <input type="text" id="takeProfit1" class="form-control" name="takeProfit1" class="pure-input-1-2" placeholder="Take Profit 1" required>
              </div>
              <div class="form-group">
                 <label for="exampleInputEmail1">Take Profit 2</label>
                  <input type="text" id="takeProfit2" class="form-control" name="takeProfit2" class="pure-input-1-2" placeholder="Take Profit 2" required>
              </div>
              <div class="form-group">
                 <label for="exampleInputEmail1">Take Profit 3</label>
                 <input type="text" id="takeProfit3" class="form-control" name="takeProfit3" class="pure-input-1-2" placeholder="Take Profit 3" required>
              </div>
              <div class="form-group">
                 <label for="exampleInputEmail1">Stop Loss</label>
                  <input type="text" id="stopLoss" class="form-control" name="stopLoss" class="pure-input-1-2" placeholder="Stop Loss" required>
              </div>
              <div class="form-group">
                 <label for="exampleInputEmail1">Profit/Loss</label>
                 <input type="text" id="profitLoss" class="form-control" name="profitLoss" class="pure-input-1-2" placeholder="Profit/Loss">
              </div>
              <div class="form-group">
                 <label for="exampleInputEmail1">Comments</label>
                 <input type="text" id="comments" class="form-control" name="comments" class="pure-input-1-2" placeholder="Comments">
              </div>
              <div class="form-group">
                 <label for="exampleInputEmail1">Signal Status</label>
                  <select class="form-control" id="status" name="status" required>
                          <option id="Active" selected>Active</option>
                          <option id="Expired">Expired</option>
                  </select>
              </div>
              <div class="form-group">
                 <label for="exampleInputEmail1">Signal Action</label>
                 <div id="typeDiv" style="border: 2px solid blue; width: 100%; margin-top: 5px; margin-bottom: 15px;">
                     <select style="width: 100%;" class="form-control"  id="action" name="action" required>
                          <option id="Buy" selected>Buy</option>
                          <option id="Sell">Sell</option>
                      </select>
                  </div>
              </div>
              <div class="form-group">
                   <label for="exampleInputEmail1">Signal Type</label>
                       <select style="width: 100%;" class="form-control"  id="type" name="type" required>
                            <option id="Normal" selected>Normal</option>
                            <option id="Vip">Vip</option>
                        </select>
               </div>
            </div>
            <input type="hidden" name="push_type" value="topic"/>
            <!-- /.card-body -->

            <div class="card-footer">
              <button type="submit" class="btn btn-primary">Submit</button>
            </div>
          </form>

        </div>


        <script>
            const selectElement = document.getElementById('action');
            const typeDiv = document.getElementById('typeDiv');

            selectElement.addEventListener('change', (event) => {
                console.log(event.target.value)
                if(event.target.value == "Buy")
                {
                    typeDiv.style.border = "2px solid blue";
                }else
                {
                    typeDiv.style.border = "2px solid red";
                }
            });
        </script>

      </div><!-- /.container-fluid -->
    </section>
    <!-- /.content -->
  </div>
    <?php include("footer.php") ?>
</div>
<!-- ./wrapper -->
<?php include("scripts.php") ?>
</body>
</html>
