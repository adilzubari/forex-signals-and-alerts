<?php
ob_start();
session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <?php include("head.html") ?>
</head>
<body class="hold-transition sidebar-mini layout-fixed">
<div class="wrapper">

  <!-- Preloader -->
  <div class="preloader flex-column justify-content-center align-items-center">
    <img class="animation__shake" src="dist/img/AdminLTELogo.png" alt="AdminLTELogo" height="60" width="60">
  </div>

   <?php include("header.php")?>
   <?php include("sidebar.php")?>

<?php

        if($_SESSION['status']=="logged_in"){

            if(isset($_POST['btn-upload'])) {

           $conn = mysqli_connect("localhost", "root", "", "signals");
           if ($conn->connect_error) {
               die("Connection failed: " . $conn->connect_error);
           }

            $file = rand(1000,100000)."-".$_FILES['file']['name'];
            $file_loc = $_FILES['file']['tmp_name'];
            $file_size = $_FILES['file']['size'];
            $file_type = $_FILES['file']['type'];
            $folder="uploads/";

            move_uploaded_file($file_loc,$folder.$file);
            $sql="INSERT INTO results(url,signal_id) VALUES('$file','$_POST[id]')";
            mysql_query($sql);

             header("Location: dashboard.php");
             die();
            }}
            ?>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <div class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1 class="m-0">Dashboard</h1>
          </div><!-- /.col -->
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="#">Home</a></li>
              <li class="breadcrumb-item active">Dashboard v1</li>
            </ol>
          </div><!-- /.col -->
        </div><!-- /.row -->
      </div><!-- /.container-fluid -->
    </div>
    <!-- /.content-header -->

    <!-- Main content -->
    <section class="content">
      <div class="container-fluid">
        <!-- Small boxes (Stat box) -->
        <div class="row">
        <div class="col-md-9 card card-primary">
          <div class="card-header">
            <h3 class="card-title">Add Signal</h3>
          </div>
          <!-- /.card-header -->
          <!-- form start -->
          <form action="apis/upload.php" method="post" enctype="multipart/form-data">
            <div class="card-body">
              <div class="form-group">
                 <label for="exampleInputEmail1">Upload File</label>
                 <input type="file" name="file"  class="form-control" required>
              </div>
            <input type="text" id="id" name="id" value="<?php echo $_GET['id']?>" hidden />
            <!-- /.card-body -->

            <div class="card-footer">
              <button type="submit" class="btn btn-primary">Submit</button>
            </div>
          </form>

        </div>


        <script>
            const selectElement = document.getElementById('action');
            const typeDiv = document.getElementById('typeDiv');

            selectElement.addEventListener('change', (event) => {
                console.log(event.target.value)
                if(event.target.value == "Buy")
                {
                    typeDiv.style.border = "2px solid blue";
                }else
                {
                    typeDiv.style.border = "2px solid red";
                }
            });
        </script>

      </div><!-- /.container-fluid -->
    </section>
    <!-- /.content -->
  </div>
    <?php include("footer.php") ?>
</div>
<!-- ./wrapper -->
<?php include("scripts.php") ?>
</body>
</html>
