<?php
 
// Firebase API Key
define('FIREBASE_API_KEY', 'AAAAcoQN7sw:APA91bG2Zuv2M7Pw8tJbEx6dJqzM5ravRdOfGxJDQQeov0GW-wX9csBGDPyCRsqwGq8ciHnW2hSgWX7LbYLI1AhwLzfE6h28cP-Fed9PdqAmODwJfHZ7v9rkshouWRe2JRv59imrTgde');

?>
