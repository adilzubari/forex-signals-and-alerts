import { Dimensions, StyleSheet } from "react-native";

export const wWidth = Dimensions.get("window").width;
export const wHeight = Dimensions.get("window").height;
export const pageBgColor = "rgb(50,50,50)";
export const FIREBASE_API_KEY =
  "AAAAsOzmnAM:APA91bHMoeGTyyhOoQqm4EMyxktdrcRJrrx7Npgw6AouSdiqz5MJeCc5sTubKM4LIEPwfksLH8V8Km29pUVhx6aZMxJjoghag4BkwN3CfY2eDBKOL6-YwHEeI7EXH17UKhwsyKqulkLu";
export const firebaseConfig = {
  apiKey: "AIzaSyCzKwXQSIVX2GC8nMqe7Xg-zqBgG0sx1ak",
  projectId: "forex-signals-fa3d3",
  messagingSenderId: "483936075466",
  appId: "1:483936075466:web:a99794bf8609e33d107e33",
  measurementId: "G-J2T08JFN3S",
};
